import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	ScrapeWebsiteTool
)





@CrewBase
class SocialMediaContentManagementAutomationCrew:
    """SocialMediaContentManagementAutomation crew"""

    
    @agent
    def social_media_content_creator(self) -> Agent:
        
        return Agent(
            config=self.agents_config["social_media_content_creator"],
            
            
            tools=[				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def creative_visual_strategist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["creative_visual_strategist"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def content_calendar_manager(self) -> Agent:
        
        return Agent(
            config=self.agents_config["content_calendar_manager"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def social_media_trends_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["social_media_trends_analyst"],
            
            
            tools=[				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def analyze_regional_and_genre_trends(self) -> Task:
        return Task(
            config=self.tasks_config["analyze_regional_and_genre_trends"],
            markdown=False,
            
            
        )
    
    @task
    def create_platform_specific_content(self) -> Task:
        return Task(
            config=self.tasks_config["create_platform_specific_content"],
            markdown=False,
            
            
        )
    
    @task
    def design_visual_content_concepts(self) -> Task:
        return Task(
            config=self.tasks_config["design_visual_content_concepts"],
            markdown=False,
            
            
        )
    
    @task
    def create_content_calendar(self) -> Task:
        return Task(
            config=self.tasks_config["create_content_calendar"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the SocialMediaContentManagementAutomation crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


